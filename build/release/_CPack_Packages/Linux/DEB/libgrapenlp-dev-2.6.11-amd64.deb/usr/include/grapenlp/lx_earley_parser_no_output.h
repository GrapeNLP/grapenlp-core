/*
 * GRAPENLP
 *
 * Copyright (C) 2004-2019 Javier Miguel Sastre Martínez <javier.sastre@telefonica.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 */

/*
 *  @author Javier Sastre
 */

#ifndef GRAPENLP_LX_EARLEY_PARSER_NO_OUTPUT_H
#define GRAPENLP_LX_EARLEY_PARSER_NO_OUTPUT_H

#include <grapenlp/earley_parser_no_output.h>
#include <grapenlp/lx_rtno.h>

namespace grapenlp
{
	template<typename InputIterator, typename SourceRef, typename Id, assoc_container_impl_choice execution_state_set_impl_choice>
#ifdef TRACE
	struct lx_earley_parser_no_output: public earley_parser_no_output<typename lxns_rtno<InputIterator, Id>::type::tag_input, typename lxns_rtno<InputIterator, Id>::type::tag_output, SourceRef, execution_state_set_impl_choice>
	{
		typedef earley_parser_no_output<typename lxns_rtno<InputIterator, Id>::type::tag_input, typename lxns_rtno<InputIterator, Id>::type::tag_output, SourceRef, execution_state_set_impl_choice> base_type;
#else
	struct lx_earley_parser_no_output: public earley_parser_no_output<typename lx_rtno<InputIterator, Id>::type::tag_input, typename lx_rtno<InputIterator, Id>::type::tag_output, SourceRef, execution_state_set_impl_choice>
	{
		typedef earley_parser_no_output<typename lx_rtno<InputIterator, Id>::type::tag_input, typename lx_rtno<InputIterator, Id>::type::tag_output, SourceRef, execution_state_set_impl_choice> base_type;
#endif
		typedef typename base_type::machine machine;
		typedef typename base_type::source_ref source_ref;
		typedef typename base_type::match match;

		lx_earley_parser_no_output(): base_type()
		{}
		lx_earley_parser_no_output(match input_match_): base_type(input_match_)
		{}

		bool operator() (const machine& m, source_ref input_begin, source_ref input_end, bool hasnt_white_at_begin, bool hasnt_white_at_end)
		{ return base_type::operator()(m, input_begin, input_end, hasnt_white_at_begin, hasnt_white_at_end); }
	};

	//This is just for homogeneity
	template<typename InputIterator, typename SourceRef, typename Id, assoc_container_impl_choice execution_state_set_impl_choice>
	struct lx_earley_parser_no_output_impl_selector
	{ typedef lx_earley_parser_no_output<InputIterator, SourceRef, Id, execution_state_set_impl_choice> type; };
} //namespace grapenlp

#endif /*GRAPENLP_LX_EARLEY_PARSER_NO_OUTPUT_H*/
