#include <grapenlp/movistarbot_tag_dico.h>

namespace grapenlp
{
	//Up to now, everything declared inline: all definitions in the corresponding header file
} //namespace grapenlp
