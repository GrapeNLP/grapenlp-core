#include <grapenlp/movistarbot_weighted_out_serializer.h>

namespace grapenlp
{
	//Up to now, everything declared inline: all definitions in the corresponding header file
} //namespace grapenlp
